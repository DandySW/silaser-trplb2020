@extends('backEnd.layouts.master')
@section('title','Show Product Page')
@section('content')
@endsection
@section('jsblock')
@endsection