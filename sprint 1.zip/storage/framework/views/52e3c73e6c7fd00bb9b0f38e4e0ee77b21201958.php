<?php $__env->startSection('title','Detail Produk | SILASER - Sistem Informasi Penjualan dan Layanan Servis Laptop'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-3">
            <?php echo $__env->make('pelanggan.layouts.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-sm-9 padding-right">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="product-details">
                <!--product-details-->

                <div class="col-sm-5">
                    <div class="easyzoom easyzoom--overlay easyzoom--with-thumbnails">
                        <a href="<?php echo e(url('products/large',$detail_product->image)); ?>">
                            <img src="<?php echo e(url('products/small',$detail_product->image)); ?>" alt="" id="dynamicImage" />
                        </a>
                    </div>

                    <ul class="thumbnails" style="margin-left: -10px;">
                        <li>
                            <a href="<?php echo e(url('products/large',$detail_product->image)); ?>" data-standard="<?php echo e(url('products/small',$detail_product->image)); ?>">
                                <img src="<?php echo e(url('products/small',$detail_product->image)); ?>" alt="" width="75" style="padding: 8px;">
                            </a>
                            <?php $__currentLoopData = $imagesGalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagesGallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('products/large',$imagesGallery->image)); ?>" data-standard="<?php echo e(url('products/small',$imagesGallery->image)); ?>">
                                <img src="<?php echo e(url('products/small',$imagesGallery->image)); ?>" alt="" width="75" style="padding: 8px;">
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-7">
                    <form action="<?php echo e(route('addToCart')); ?>" method="post" role="form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="products_id" value="<?php echo e($detail_product->id); ?>">
                        <input type="hidden" name="price" value="<?php echo e($detail_product->price); ?>" id="dynamicPriceInput">
                        <div class="product-information">
                            <!--/product-information-->
                            <img src="<?php echo e(asset('pelanggan/images/product-details/new.jpg')); ?>" class="newarrival" alt="product_image" />
                            <h2><?php echo e($detail_product->p_name); ?></h2>
                            <span>
                                <span id="dynamic_price">Rp <?php echo e(number_format($detail_product->price,0,',','.')); ?></span>
                                <?php if($detail_product->stock>0): ?>
                                <label>Jumlah:</label>
                                <input type="text" name="quantity" value="1" id="inputStock" />
                                <button type="submit" class="btn btn-fefault cart" id="buttonAddToCart">
                                    <i class="fa fa-shopping-cart"></i>
                                    Add to cart
                                </button>
                                <?php endif; ?>
                            </span>
                            <p><b>Stock:</b>
                                <?php if($detail_product->stock>0): ?>
                                <span id="availableStock"><?php echo e($detail_product->stock); ?></span>
                                <?php else: ?>
                                <span id="availableStock">Kosong</span>
                                <?php endif; ?>
                            </p>
                            <p><b>Kondisi:</b> Baru</p>
                            <a href="#"><img src="<?php echo e(asset('pelanggan/images/product-details/share.png')); ?>" class="share img-responsive" alt="" /></a>
                        </div>
                        <!--/product-information-->
                    </form>

                </div>
            </div>
            <!--/product-details-->

            <div class="category-tab shop-details-tab">
                <!--category-tab-->
                <div class="col-sm-12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#details" data-toggle="tab">Details</a></li>
                    </ul>
                </div>
                <div class="tab-content">
                    <div class="tab-pane fade active in" id="details">
                        {<?php echo $detail_product->description; ?>}
                    </div>

                </div>
            </div>
            <!--/category-tab-->

            <div class="recommended_items">
                <!--recommended_items-->
                <h2 class="title text-center">Produk Lain</h2>

                <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $countChunk = 0; ?>
                        <?php $__currentLoopData = $relateProducts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $countChunk++; ?>
                        <div class="item<?php if ($countChunk == 1) {
                                            echo ' active';
                                        } ?>">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo text-center">
                                            <img src="<?php echo e(url('/products/small',$item->image)); ?>" alt="" style="width: 150px;" />
                                            <h2><?php echo e($item->price); ?></h2>
                                            <p><?php echo e($item->p_name); ?></p>
                                            <button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Tambah ke dalam Keranjang</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </div>
            <!--/recommended_items-->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>