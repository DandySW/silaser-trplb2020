<?php $__env->startSection('title','Konfirmasi Pengiriman'); ?>
<?php $__env->startSection('content'); ?>
<div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Orders</a> <a href="<?php echo e(url('admin/orders/sedang-proses')); ?>" class="current">Sedang Proses</a> </div>
<div class="container-fluid">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success text-center" role="alert">
        <strong>Well done! &nbsp;</strong><?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
            <h5>Konfirmasi Pengiriman #<?php echo e($order->id); ?></h5>
        </div>
        <div class="widget-content nopadding">
            <form action="<?php echo e(route('pengiriman',$order->id)); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field("PUT")); ?>

                <input type="hidden" name="shipping_status" value="sudah dikirim">
                <div class="control-group">
                    <label for="resi" class="control-label">No Resi</label>
                    <div class="controls<?php echo e($errors->has('resi')?' has-error':''); ?>">
                        <input type="text" name="resi" id="resi" class="form-control" required="required" style="width: 200px;">
                        <span class="text-danger"><?php echo e($errors->first('resi')); ?></span>
                    </div>
                </div>

                <div class="control-group">
                    <label for="shipping_date" class="control-label">Tanggal Pengiriman</label>
                    <div class="controls<?php echo e($errors->has('shipping_date')?' has-error':''); ?>">
                        <div class="input-prepend">
                            <div data-date="12-02-2012" class="input-append date datepicker">
                                <input type="text" name="shipping_date" id="shipping_date" data-date-format="yyyy-mm-dd" class="span11" style="width: 175px;" placeholder="yyyy-mm-dd">
                                <span class="add-on"><i class="icon-th"></i></span>
                            </div>
                        </div>
                        <span class="text-danger"><?php echo e($errors->first('shipping_date')); ?></span>
                    </div>
                </div>
                <div class="control-group">
                    <label for="" class="control-label"></label>
                    <div class="controls">
                        <button type="submit" class="btn btn-warning">Konfirmasi Pengiriman</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-colorpicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.toggle.buttons.js')); ?>"></script>
<script src="<?php echo e(asset('js/masked.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.form_common.js')); ?>"></script>
<script src="<?php echo e(asset('js/wysihtml5-0.3.0.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-wysihtml5.js')); ?>"></script>
<script>
    $('.textarea_editor').wysihtml5();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>