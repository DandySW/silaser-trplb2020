<?php $__env->startSection('title','Order Payment'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('order user'); ?>
<h3 class="text-center">PESANAN ANDA TELAH KAMI TERIMA</h3>
<p class="text-center">Terimakasih telah memesan produk di toko kami. Silahkan lakukan pembayaran agar pesanan anda dapat segera kami proses.</p>
<div style="margin-bottom: 20px;"></div>

<div class="card" style="margin-right: 100px; margin-left: 100px;">
    <ul class="list-group list-group-flush">
        <li class="list-group-item">ID Order: <b>#<?php echo e($user_order->id); ?></b></li>
        <li class="list-group-item">Nama Pelanggan: <b><?php echo e($user->name); ?></b></li>
        <li class="list-group-item">Produk dipesan: <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($detail->orders_id == $user_order->id): ?>
            <b> <?php echo e($detail->p_name); ?> (<?php echo e($detail->quantity); ?>) </b>;
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
        <li class="list-group-item">Total: <b>Rp <?php echo e(number_format($user_order->grand_total,0,',','.')); ?></b></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('payment.payment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>