<?php $__env->startSection('title','Data Produk | Sistem Informasi Penjualan dan Layanan Servis Laptop '); ?>
<?php $__env->startSection('content'); ?>
<div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Detail Pemesanan</a> <a href="<?php echo e(url('admin/orders/belum-dibayar')); ?>" class="current">Belum Dibayar</a> </div>
<div class="container-fluid">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success text-center" role="alert">
        <strong>Well done!</strong> <?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Belum Dibayar</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>Pelanggan</th>
                        <th>ID Ekspedisi</th>
                        <th>Ongkir</th>
                        <th>ID Kupon</th>
                        <th>Nilai Kupon</th>
                        <th>Total</th>
                        <th>Tanggal Pemesanan</th>
                        <th>Status Pembayaran</th>
                        <th>Bukti Pembayaran</th>
                        <th>Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeC">
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td style="text-align: center; vertical-align: middle;">
                            <a href="#modalDetail<?php echo e($order->id); ?>" data-toggle="modal" class="btn btn-default btn-mini"><?php echo e($order->id); ?></a>
                        </td>
                        <td style="vertical-align: middle;"><?php echo e($order->name); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($order->expedition); ?></td>
                        <td style="vertical-align: middle;">Rp <?php echo e(number_format($order->shipping_charge,0,',','.')); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($order->coupon_id); ?></td>
                        <td style="vertical-align: middle;text-align: center;">Rp <?php echo e(number_format($order->coupon_amount,0,',','.')); ?></td>
                        <td style="vertical-align: middle;text-align: center;">Rp <?php echo e(number_format($order->grand_total,0,',','.')); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($order->order_date); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($order->checkout_status); ?></td>
                        <td style="text-align: center; vertical-align: middle;">
                            <a href="#modalStruk<?php echo e($order->id); ?>" data-toggle="modal" class="btn btn-info btn-mini">View</a>
                        </td>
                        <td style="text-align: center; vertical-align: middle;">
                            <a href="<?php echo e(route('pembayaran',$order->id)); ?>" class="btn btn-warning btn-mini">Sudah Dibayar</a>
                        </td>
                    </tr>
                    
                    <div id="modalStruk<?php echo e($order->id); ?>" class="modal hide">
                        <div class="modal-header">
                            <button data-dismiss="modal" class="close" type="button">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center"><img src="<?php echo e(url('/checkout',$order->struk)); ?>" alt="Belum ada bukti pembayaran"></div>
                        </div>
                    </div>
                    

                    
                    <div id="modalDetail<?php echo e($order->id); ?>" class="modal hide">
                        <div class="modal-header">
                            <button data-dismiss="modal" class="close" type="button">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center">
                                <h5>Order Details: Order #<?php echo e($order->id); ?></h5>
                                ===================================================================
                                <h6 class="text-left">Produk yang dipesan</h6>
                                <ol>
                                    <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($orderdetail->orders_id == $order->id): ?>
                                    <li class="text-left"><?php echo e($orderdetail->p_name); ?>: <?php echo e($orderdetail->quantity); ?></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                                <br>
                                <h6 class="text-left">Detail Pelanggan</h6>
                                <ul>
                                    <li class="text-left">Nama Pelanggan: <?php echo e($order->name); ?></li>
                                    <li class="text-left">Alamat: <?php echo e($order->address); ?></li>
                                    <li class="text-left">Kelurahan: <?php echo e($order->kelurahan); ?></li>
                                    <li class="text-left">Kecamatan: <?php echo e($order->kecamatan); ?></li>
                                    <li class="text-left">Kode Pos: <?php echo e($order->postcode); ?></li>
                                    <li class="text-left">Handphone: <?php echo e($order->mobile); ?></li>
                                </ul>
                                <br>
                                <h6 class="text-left">Jasa Ekspedisi</h6>
                                <ul>
                                    <li class="text-left">Nama Ekspedisi: <?php echo e($order->expedition_name); ?></li>
                                    <li class="text-left">Tipe: <?php echo e($order->type); ?></li>
                                    <li class="text-left">Estimasi: <?php echo e($order->estimation); ?></li>
                                </ul>
                                <br>
                                <?php if($order->coupon_id != 0): ?>
                                <h6 class="text-left">Kupon</h6>
                                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($order->coupon_id == $coupon->id): ?>
                                <p class="text-left">Kode Kupon: <?php echo e($coupon->coupon_code); ?></p>
                                <?php break; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <h6 class="text-left">Kupon</h6>
                                <p class="text-left">Tidak ada Kupon</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>