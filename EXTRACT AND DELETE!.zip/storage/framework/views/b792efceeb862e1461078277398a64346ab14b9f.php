<div class="left-sidebar">
    <?php
    $categories = DB::table('categories')->get();
    ?>
    <h2>Daftar Kategori</h2>
    <div class="panel-group category-products" id="accordian">
        <!--category-productsr-->
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a href="<?php echo e(route('cats',$category->id)); ?>"><?php echo e($category->name); ?></a>
                </h4>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!--/category-products-->

</div>