<div class="row-fluid">
    <div id="footer" class="span12">Teknik Rekayasa Perangkat Lunak 2020 | Kelas B - Kelompok H</div>
</div>