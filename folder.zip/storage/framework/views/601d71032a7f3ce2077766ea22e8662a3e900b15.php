<?php $__env->startSection('title','Data Produk | Sistem Informasi Penjualan dan Layanan Servis Laptop '); ?>
<?php $__env->startSection('content'); ?>
<div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="<?php echo e(route('product.index')); ?>" class="current">Products</a></div>
<div class="container-fluid">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success text-center" role="alert">
        <strong>Well done!</strong> <?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Daftar Produk</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Gambar</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Image Gallery</th>
                        <th>Berat</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeC">
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td style="text-align: center;"><img src="<?php echo e(url('products/small',$product->image)); ?>" alt="" width="50"></td>
                        <td style="vertical-align: middle;"><?php echo e($product->p_name); ?></td>
                        <td style="vertical-align: middle;"><?php echo e($product->category->name); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($product->price); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($product->stock); ?></td>
                        <td style="vertical-align: middle;text-align: center;"><a href="<?php echo e(route('image-gallery.show',$product->id)); ?>" class="btn btn-default btn-mini">Add Images</a></td>
                        <td style="vertical-align: middle;text-align: center;"><?php echo e($product->weight); ?></td>
                        <td style="text-align: center; vertical-align: middle;">
                            <a href="#myModal<?php echo e($product->id); ?>" data-toggle="modal" class="btn btn-info btn-mini">View</a>
                            <a href="<?php echo e(route('product.edit',$product->id)); ?>" class="btn btn-primary btn-mini">Edit</a>
                            <a href="javascript:" rel="<?php echo e($product->id); ?>" rel1="delete-product" class="btn btn-danger btn-mini deleteRecord">Delete</a>
                        </td>
                    </tr>
                    
                    <div id="myModal<?php echo e($product->id); ?>" class="modal hide">
                        <div class="modal-header">
                            <button data-dismiss="modal" class="close" type="button">×</button>
                            <h3><?php echo e($product->p_name); ?></h3>
                        </div>
                        <div class="modal-body">
                            <div class="text-center"><img src="<?php echo e(url('/storage/products/small',$product->gambar)); ?>" width="100" alt="<?php echo e($product->no_arcode); ?>"></div>
                            <p class="text-center"><?php echo e($product->description); ?></p>
                        </div>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script>
    $(".deleteRecord").click(function() {
        var id = $(this).attr('rel');
        var deleteFunction = $(this).attr('rel1');
        swal({
            title: 'Apakah kamu yakin akan menghapus produk?',
            text: "Tindakan tidak dapat dikembalikan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#da4f49',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oke',
            cancelButtonText: 'Batal',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false,
            reverseButtons: true
        }, function() {
            window.location.href = "/admin/" + deleteFunction + "/" + id;
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>