<?php $__env->startSection('title','checkOut Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="row">
        <form action="<?php echo e(url('/submit-checkout')); ?>" method="post" class="form-horizontal">

            <?php for($i=0; $i<3; $i++): ?> <div class="col-sm-1">
    </div>
    <?php endfor; ?>

    <div class="col-sm-4 col-sm-offset-1">
        <div class="login-form">
            <!--Form Alamat-->
            <?php echo csrf_field(); ?>
            <legend>Alamat Pengiriman</legend>
            <div class="form-group <?php echo e($errors->has('billing_name')?'has-error':''); ?>">
                <input type="text" class="form-control" name="billing_name" id="billing_name" value="<?php echo e($user_login->name); ?>" placeholder="Nama Pembeli" readonly>
                <span class="text-danger"><?php echo e($errors->first('billing_name')); ?></span>
            </div>
            <div class="form-group <?php echo e($errors->has('billing_address')?'has-error':''); ?>">
                <input type="text" class="form-control" value="<?php echo e($user_login->address); ?>" name="billing_address" id="billing_address" placeholder="Alamat, Keluarahan, Kecamatan">
                <span class="text-danger"><?php echo e($errors->first('billing_address')); ?></span>
            </div>
            <div class="form-group <?php echo e($errors->has('billing_postcode')?'has-error':''); ?>">
                <input type="text" class="form-control" value="<?php echo e($user_login->postcode); ?>" name="billing_postcode" id="billing_postcode" placeholder="Kode Pos">
                <span class="text-danger"><?php echo e($errors->first('billing_postcode')); ?></span>
            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('billing_mobile')?'has-error':''); ?>">
            <input type="text" class="form-control" value="<?php echo e($user_login->mobile); ?>" name="billing_mobile" id="billing_mobile" placeholder="No HP">
            <span class="text-danger"><?php echo e($errors->first('billing_mobile')); ?></span>
        </div>
        <button type="submit" class="btn btn-primary" style="float: right;">CheckOut</button>
    </div>
    <!--/login form-->
</div>
<div class="col-sm-1">
    </form>
</div>
</div>
<div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>