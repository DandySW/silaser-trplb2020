<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('/admin')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
    <ul>
        <li<?php echo e($menu_active==1? ' class=active':''); ?>><a href="<?php echo e(url('/admin')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
            <li class="submenu <?php echo e($menu_active==2? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Kategori</span></a>
                <ul>
                    <li><a href="<?php echo e(url('/admin/category/create')); ?>">Tambah Kategori</a></li>
                    <li><a href="<?php echo e(route('category.index')); ?>">Daftar Kategori</a></li>
                </ul>
            </li>
            <li class="submenu <?php echo e($menu_active==3? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Produk</span></a>
                <ul>
                    <li><a href="<?php echo e(url('/admin/product/create')); ?>">Tambah Produk</a></li>
                    <li><a href="<?php echo e(route('product.index')); ?>">Daftar Produk</a></li>
                </ul>
            </li>
            <li class="submenu <?php echo e($menu_active==4? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Detail Pemesanan</span></a>
                <ul>
                    <li><a href="<?php echo e(url('admin/orders/belum-dibayar')); ?>">Belum Dibayar</a></li>
                    <li><a href="<?php echo e(url('admin/orders/sedang-proses')); ?>">Sedang Proses</a></li>
                    <li><a href="<?php echo e(url('admin/orders/sudah-selesai')); ?>">Sudah Selesai</a></li>
                </ul>
            </li>
            <li class="submenu <?php echo e($menu_active==5? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Kupon</span></a>
                <ul>
                    <li><a href="<?php echo e(url('/admin/coupon/create')); ?>">Tambah Kupon</a></li>
                    <li><a href="<?php echo e(route('coupon.index')); ?>">Daftar Kupon</a></li>
                </ul>
            </li>
    </ul>
</div>
<!--sidebar-menu-->