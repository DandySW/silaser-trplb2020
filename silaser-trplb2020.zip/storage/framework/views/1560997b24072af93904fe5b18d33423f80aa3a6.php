<?php $__env->startSection('title','Review Order Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="step-one">
        <h2 class="heading">Shipping To</h2>
    </div>
    <div class="row">
        <form action="<?php echo e(url('/submit-order')); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="users_id" value="<?php echo e($user_data->id); ?>">
            <input type="hidden" name="address" value="<?php echo e($user_data->address); ?>">
            <input type="hidden" name="kelurahan" value="<?php echo e($user_data->kelurahan); ?>">
            <input type="hidden" name="kecamatan" value="<?php echo e($user_data->kecamatan); ?>">
            <input type="hidden" name="postcode" value="<?php echo e($user_data->postcode); ?>">
            <input type="hidden" name="mobile" value="<?php echo e($user_data->mobile); ?>">
            <?php if(Session::has('expedition')): ?>
            <input type="hidden" name="expedition" value="<?php echo e(Session::get('expedition')); ?>">
            <input type="hidden" name="shipping_charge" value="<?php echo e(Session::get('expedition_total')); ?>">
            <?php else: ?>
            <input type="hidden" name="expedition" value="1">
            <input type="hidden" name="shipping_charge" value="10">
            <?php endif; ?>
            <input type="hidden" name="order_date" value="<?php echo e(date('Y-m-d')); ?>" data-date-format="yyyy-mm-dd">
            <?php if(Session::has('discount_amount_price')): ?>
            <input type="hidden" name="coupon_id" value="<?php echo e($coupon_id); ?>">
            <input type="hidden" name="coupon_amount" value="<?php echo e(Session::get('discount_amount_price')); ?>">
            <input type="hidden" name="grand_total" value="<?php echo e($total_price+Session::get('expedition_total')-Session::get('discount_amount_price')+$order_id); ?>">
            <?php else: ?>
            <input type="hidden" name="coupon_id" value="">
            <input type="hidden" name="coupon_amount" value="">
            <input type="hidden" name="grand_total" value="<?php echo e($total_price+Session::get('expedition_total')+$order_id); ?>">
            <?php endif; ?>

            <div class="col-sm-12">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Kelurahan/Desa</th>
                                <th>Kecamatan</th>
                                <th>Kode Pos</th>
                                <th>Email</th>
                                <th>No. HP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($user_data->name); ?></td>
                                <td><?php echo e($user_data->address); ?></td>
                                <td><?php echo e($user_data->kelurahan); ?></td>
                                <td><?php echo e($user_data->kecamatan); ?></td>
                                <td><?php echo e($user_data->postcode); ?></td>
                                <td><?php echo e($user_data->email); ?></td>
                                <td><?php echo e($user_data->mobile); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <section id="cart_items">
                    <div class="review-payment">
                        <h2>Review & Payment</h2>
                    </div>
                    <div class="table-responsive cart_info">
                        <table class="table table-condensed">
                            <thead>
                                <tr class="cart_menu">
                                    <td class="image">Produk</td>
                                    <td class="description"></td>
                                    <td class="price">Harga</td>
                                    <td class="quantity">Jumlah</td>
                                    <td class="total">Total</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cart_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="cart_product">
                                        <a href=""><img src="<?php echo e(url('products/small',$cart_data->image)); ?>" alt="" style="width: 100px;"></a>
                                    </td>
                                    <td class="cart_description">
                                        <h4><a href=""><?php echo e($cart_data->p_name); ?></a></h4>
                                        <?= '<p>' . (substr($cart_data->description, 0, 30)) . '...' . '</p>' ?>
                                    </td>
                                    <td class="cart_price">
                                        <p>Rp <?php echo e($cart_data->price); ?></p>
                                    </td>
                                    <td class="cart_price">
                                        <p><?php echo e($cart_data->quantity); ?></p>
                                    </td>
                                    <td class="cart_total">
                                        <p class="cart_total_price">Rp <?php echo e($cart_data->price*$cart_data->quantity); ?></p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="4">&nbsp;</td>
                                    <td colspan="2">
                                        <table class="table table-condensed total-result">
                                            <tr>
                                                <td>Cart Sub Total</td>
                                                <td>Rp <?php echo e($total_price); ?></td>
                                            </tr>
                                            <?php if(Session::has('expedition_total')): ?>
                                            <tr>
                                                <td>Ongkir</td>
                                                <td>Rp <?php echo e(Session::get('expedition_total')); ?></td>
                                            </tr>
                                            <?php if(Session::has('discount_amount_price')): ?>
                                            <tr class="shipping-cost">
                                                <td>Coupon Discount</td>
                                                <td>- Rp <?php echo e(Session::get('discount_amount_price')); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Kode Unik Pembayaran</td>
                                                <td>Rp <?php echo e($order_id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total</td>
                                                <td><span>Rp <?php echo e($total_price+Session::get('expedition_total')-Session::get('discount_amount_price')+$order_id); ?></span></td>
                                            </tr>
                                            <?php else: ?>
                                            <tr>
                                                <td>Kode Unik</td>
                                                <td>Rp <?php echo e($order_id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total</td>
                                                <td><span>Rp <?php echo e($total_price+Session::get('expedition_total')+$order_id); ?></span></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <tr>
                                                <td>Ongkir</td>
                                                <td>Rp 10000</td>
                                            </tr>
                                            <?php if(Session::has('discount_amount_price')): ?>
                                            <tr class="shipping-cost">
                                                <td>Coupon Discount</td>
                                                <td>- Rp <?php echo e(Session::get('discount_amount_price')); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Kode Unik</td>
                                                <td>Rp <?php echo e($order_id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total</td>
                                                <td><span>Rp <?php echo e($total_price+10-Session::get('discount_amount_price')+$order_id); ?></span></td>
                                            </tr>
                                            <?php else: ?>
                                            <tr>
                                                <td>Kode Unik</td>
                                                <td>Rp <?php echo e($order_id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total</td>
                                                <td><span>Rp <?php echo e($total_price+10+$order_id); ?></span></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="payment-options">
                        <button type="submit" class="btn btn-primary" style="float: right;">Bayar Sekarang</button>
                    </div>
                </section>

            </div>
        </form>
    </div>
</div>
<div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pelanggan.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>