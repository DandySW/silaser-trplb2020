<?php $__env->startSection('title','Edit Kategori | SILASER - Sistem Informasi Penjualan dan Layanan Servis Laptop'); ?>
<?php $__env->startSection('content'); ?>
<div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="<?php echo e(route('category.index')); ?>">Daftar Kategori</a> <a href="#" class="current">Edit Kategori</a> </div>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="span12">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                    <h5>Edit Kateogri</h5>
                </div>
                <div class="widget-content nopadding">
                    <form class="form-horizontal" method="post" action="<?php echo e(route('category.update',$categories->id)); ?>" name="basic_validate" id="basic_validate" novalidate="novalidate">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field("PUT")); ?>

                        <div>
                            <label class="control-label">ID:</label>
                            <div class="controls">
                                <input type="text" name="id" id="id" value="<?php echo e($categories->id); ?>" readonly>
                            </div>
                        </div>
                        <div class="control-group<?php echo e($errors->has('name')?' has-error':''); ?>">
                            <label class="control-label">Nama Kategori:</label>
                            <div class="controls">
                                <input type="text" name="name" id="name" value="<?php echo e($categories->name); ?>" required>
                                <span class="text-danger" style="color: red;"><?php echo e($errors->first('name')); ?></span>
                            </div>
                        </div>
                        <label for="control-label"></label>
                        <div class="controls">
                            <a href="<?php echo e(url('/admin/category')); ?>"><button type="button" class="btn btn-info">Batal</button></a>
                            <input type="submit" value="Update" class="btn btn-success">
                        </div>
                </div>
                <div class="control-group">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.form_validation.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
<script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>