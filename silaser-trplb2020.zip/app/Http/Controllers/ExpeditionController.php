<?php

namespace App\Http\Controllers;

use App\Expedition_model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class ExpeditionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function applyexpedition(Request $request)
    {
        $this->validate($request, [
            'expedition' => 'required'
        ]);


        $input_data = $request->all();
        Session::forget('discount_amount_price');
        Session::forget('coupon_code');
        $auth_id = Auth::id();

        $expedition = $input_data['expedition'];
        $expedition_charge = DB::select("SELECT base_charge FROM `expeditions` WHERE id = $expedition");

        $products = DB::select("SELECT sum(cart.quantity*products.weight) as quantityweight FROM `cart`,`products` WHERE cart.products_id = products.id and cart.users_id = $auth_id");
        foreach ($expedition_charge as $charge) {
            $base_charge = $charge->base_charge;
            foreach ($products as $product) {
                $sum_prod = $product->quantityweight;
            }
            if ($sum_prod <= 1500) {
                $expedition_total = $base_charge;
            } else {
                $cons = 2500;
                while ($sum_prod >= $cons) {
                    $cons = $cons + 1000;
                }
                $int = floor($cons / 1000);
                $expedition_total = $base_charge * $int;
            }
        }
        Session::put('expedition', $expedition);
        Session::put('expedition_total', $expedition_total);
        return back()->with('message_apply_sucess', 'Berhasil memilih ekspedisi');
    }
}
