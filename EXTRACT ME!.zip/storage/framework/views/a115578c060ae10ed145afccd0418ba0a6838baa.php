<?php $__env->startSection('title', 'Review Order Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card"
                    style="border-style: solid; border-width: thin; border-color: #FE980F; margin-bottom: 20px;">
                    <div style="margin-left: 10px;">
                        <h5 class="card-header">ID Pemesanan: #<?php echo e($order->id); ?> (<?php echo e($order->order_date); ?>)</h5>
                        <div class="card-body">
                            <div class="row">
                                <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($orderdetail->orders_id == $order->id): ?>
                                        <div class="col-sm-2">
                                            <div class="card" style="width: 18rem;">
                                                <img src="/products/small/<?php echo e($orderdetail->image); ?>"
                                                    style="width: 150px; height: 150px;">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?php echo e($orderdetail->p_name); ?></h5>
                                                    <p class="card-text">Harga: Rp <?php echo e(number_format($orderdetail->price,0,',','.')); ?>

                                                        <br>Jumlah: <?php echo e($orderdetail->quantity); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <a href="#modalDetailOrder<?php echo e($order->id); ?>" class="btn btn-primary" data-toggle="modal">Detail
                        Pemesanan</a>
                    <a href="#modalStruk<?php echo e($order->id); ?>" class="btn btn-primary" data-toggle="modal">Bukti Pembayaran</a>
                </div>

                
                <div class="modal fade" id="modalStruk<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="modalStrukLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="modalStrukLabel">Upload Bukti Pembayaran</h4>Tunggu hingga admin
                                memverifikasi bukti pembayaran
                            </div>
                            <div class="modal-body">
                                <img src="<?php echo e(url('/checkout', $order->struk)); ?>" alt="Belum ada bukti pembayaran">
                                <form action="<?php echo e(route('uploadpembayaran', $order->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <input type="file" class="form-control" name="struk" id="struk"
                                        accept="image/png, image/jpeg, image/jpg" required>
                                    <span class="text-danger"><?php echo e($errors->first('struk')); ?></span>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Simpan Bukti Pembayaran</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                

                
                <div class="modal fade" id="modalDetailOrder<?php echo e($order->id); ?>" tabindex="-1"
                    aria-labelledby="modalDetailOrderLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="modalStrukLabel">Detail Pemesanan #<?php echo e($order->id); ?></h4>
                            </div>
                            <div class="modal-body">
                                <h5><i class="fa fa-map-marker"></i> Alamat Pengiriman</h5>
                                <p style="text-align: justify">
                                    <?php echo e($order->name); ?><br><?php echo e($order->mobile); ?><br><?php echo e($order->address); ?><br><?php echo e($order->kelurahan); ?>,
                                    <?php echo e($order->kecamatan); ?> <?php echo e($order->postcode); ?>

                                </p>
                                <br>
                                <h5><i class="fa fa-truck"></i> Jasa Ekspedisi</h5>
                                <p><?php echo e($order->expedition_name); ?><br><?php echo e($order->type); ?> <?php echo e($order->estimation); ?></p>
                                <br>
                                <h5><i class="fa fa-money"></i> Informasi Pembayaran</h5>
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td>Sub Total:</td>
                                            <td>Rp
                                                <?php echo e(number_format($order->grand_total - $order->id + $order->coupon_amount - $order->shipping_charge,0,',','.')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Ongkir:</td>
                                            <td>Rp <?php echo e(number_format($order->shipping_charge,0,',','.')); ?></td>
                                        </tr>
                                        <?php if($order->coupon_id != 0): ?>
                                            <td>Kupon:</td>
                                            <td>- Rp <?php echo e(number_format($order->coupon_amount,0,',','.')); ?></td>
                                        <?php endif; ?>
                                        <tr>
                                            <td>Kode Unik:</td>
                                            <td>Rp <?php echo e(number_format($order->id,0,',','.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td><b>Total:</b></td>
                                            <td><b>Rp <?php echo e(number_format($order->grand_total,0,',','.')); ?></b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>