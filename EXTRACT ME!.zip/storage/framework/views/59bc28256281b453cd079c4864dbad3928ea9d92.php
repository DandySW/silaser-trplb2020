<header id="header">
    <!--header-->
    <div class="header_top">
        <!--header_top-->
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="contactinfo">
                        <ul class="nav nav-pills">
                            <li><a>SILASER - Sistem Informasi Penjualan dan Layanan Servis Laptop</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="social-icons pull-right">
                        <ul class="nav navbar-nav">
                            <li><a href="https://github.com/DandySW/silaser-trplb2020"><i class="fa fa-github"></i></a></li>
                            <li><a href="https://trello.com/b/ksICDmw2/ppl-d-kelas-a"><i class="fa fa-trello"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/header_top-->

    <div class="header-middle">
        <!--header-middle-->
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="logo pull-left">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('pelanggan/images/home/logo.png')); ?>" alt="" /></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="shop-menu pull-right">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo e(url('/viewcart')); ?>"><i class="fa fa-shopping-cart"></i> Keranjang</a></li>
                            <?php if(Auth::check()): ?>
                                <li><a href="<?php echo e(url('/myaccount')); ?>"><i class="fa fa-user"></i> Akun Saya</a></li>
                                <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-lock"></i> Logout </a>
                                </li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('/login_page')); ?>"><i class="fa fa-lock"></i> Login</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/header-middle-->

    <div class="header-bottom">
        <!--header-bottom-->
        <div class="container">
            <div class="row">
                <div class="col-sm-9">
                    <div class="mainmenu pull-left">
                        <ul class="nav navbar-nav collapse navbar-collapse">
                            <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
                            <li class="dropdown"><a href="#">Detail Pemesanan<i class="fa fa-angle-down"></i></a>
                                <ul role="menu" class="sub-menu">
                                    <li><a href="<?php echo e(url('/orders/belum-dibayar')); ?>">Belum Dibayar</a></li>
                                    <li><a href="<?php echo e(url('/orders/sedang-proses')); ?>">Sedang Proses</a></li>
                                    <li><a href="<?php echo e(url('/orders/sudah-selesai')); ?>">Sudah Selesai</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('/payment')); ?>">Cara Pembayaran</a></li>
                            <li><a href="#" target="_blank">Jasa Konsultasi</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/header-bottom-->
</header>
<!--/header-->
