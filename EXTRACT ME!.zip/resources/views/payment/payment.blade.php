@extends('pelanggan.layouts.master')
@section('title','Review Order Page')
@section('slider')
@endsection
@section('content')
<div class="container">

    @yield('order user')

    <div class="row" style="margin-left: 60px;">
        <div class="col-md-4" style="margin-bottom: 20px;">
            <div class="card">
                <img src="/pelanggan/images/payment/gopay.png" class="card-img-top" alt="gopay" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-bottom: 20px;">
            <div class="card">
                <img src="/pelanggan/images/payment/ovo.png" class="card-img-top" alt="ovo" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-bottom: 20px;">
            <div class="card">
                <img src="/pelanggan/images/payment/dana.png" class="card-img-top" alt="dana" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-bottom: 10px;">
            <div class="card">
                <img src="/pelanggan/images/payment/bni.png" class="card-img-top" alt="bni" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-bottom: 10px;">
            <div class="card">
                <img src="/pelanggan/images/payment/bri.png" class="card-img-top" alt="bri" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-bottom: 10px;">
            <div class="card">
                <img src="/pelanggan/images/payment/mandiri.png" class="card-img-top" alt="mandiri" style="margin-bottom: 5px;">
                <div class="card-body" style="width: 286px; text-align: justify;">
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content. Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection